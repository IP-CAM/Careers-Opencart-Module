<?php
class ModelCatalogCareers extends Model {
	public function sendMail($data) {
	
	 $this->emailTheCV($data['email'], $data['download_description'], $data['download'], $data['downpath']);
	
	}

	public function emailTheCV($email, $name, $thecv, $cvlocation) {
		$this->load->language('information/careers');
		$subject = sprintf($this->language->get('email_subject'), $name);
		$message = $this->language->get('email_greeting') . "\n\n";
		$message .= sprintf($this->language->get('email_text_1'), $name, $email) . "\n";
		$message .= sprintf($this->language->get('email_text_2'), $cvlocation, $thecv) . "\n\n";
		$message .= sprintf($this->language->get('email_text_3')) . "\n";
		$message .= $this->config->get('config_name');
		$mail = new Mail();
		$mail->protocol = $this->config->get('config_mail_protocol');
		$mail->hostname = $this->config->get('config_smtp_host');
		$mail->username = $this->config->get('config_smtp_username');
		$mail->password = $this->config->get('config_smtp_password');
		$mail->port = $this->config->get('config_smtp_port');
		$mail->timeout = $this->config->get('config_smtp_timeout');
		$mail->setTo($this->config->get('config_email'));
		$mail->setFrom($email);
		$mail->setSender($name);
		$mail->setSubject($subject);
		$mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
		$mail->send();
	}

}
?>
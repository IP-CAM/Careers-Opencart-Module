<?php
// Heading
$_['heading_title']     = 'Careers';

// Text
$_['text_careers'] = 'Please use the form below to submit your CV!';
$_['text_attachcv'] = 'Attach CV:';
$_['text_click']        = 'Click to Send';
$_['text_thanks']       = '<h4>Thank you for submitting your CV.</h4><h4>We will get back to you.</h4>';
$_['text_submitcv']       = 'Submit your CV';

// Entry
$_['entry_name']        = 'Your name:';
$_['entry_email']       = 'Your email:';
$_['entry_download']    = 'Attach CV:';
$_['entry_captcha']     = 'Enter the code in the box below:';

// Error
$_['error_name']        = 'Name required!';
$_['error_email']       = 'Valid email address required!';
$_['error_download']    = 'No file attached. Attach a file (pdf or Word)!';
$_['error_filename']   = 'Filename must be between 3 and 128 characters!';
$_['error_filetype']   = 'Invalid file type!';
$_['error_filesize']   = 'Invalid file size!';
$_['error_captcha']     = 'Verification code does not match the image!';

// Email
$_['email_subject']     = 'A new CV from %s';
$_['email_greeting']    = 'Hi,';
$_['email_text_1']      = '%s, whose email address is %s, has submitted a CV for consideration.';
$_['email_text_2']      = 'Download it here: %s%s.';
$_['email_text_3']      = 'Kind Regards,';
?>
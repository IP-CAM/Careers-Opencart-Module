<?php
class ControllerInformationCareers extends Controller {
	private $error = array(); 

	public function index() {
		$this->language->load('information/careers');

    		$this->document->setTitle($this->language->get('heading_title')); 

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			
			$data2 = array();
			
			if (is_uploaded_file($this->request->files['download']['tmp_name'])) {
				$filename = $this->request->files['download']['name'] . '.' . md5(rand());
				
				move_uploaded_file($this->request->files['download']['tmp_name'], DIR_DOWNLOAD . $filename);

				if (file_exists(DIR_DOWNLOAD . $filename)) {
					$data['download'] = $filename;
					$data['downpath'] = HTTP_SERVER."download/";
					$data['mask'] = $this->request->files['download']['name'];
				}
			}

			$this->load->model('catalog/careers');
			$this->model_catalog_careers->sendMail(array_merge($this->request->post, $data));

			$this->data['thanks'] = TRUE;
		}

		$this->data['breadcrumbs'] = array();
		$this->data['breadcrumbs'][] = array(
			'href'      => $this->url->link('common/home'),
			'text'      => $this->language->get('text_home'),
			'separator' => FALSE
		);
		$this->data['breadcrumbs'][] = array(
			'href'      => $this->url->link('information/careers'),
			'text'      => $this->language->get('heading_title'),
			'separator' => $this->language->get('text_separator')
		);
		$this->data['heading_title'] = $this->language->get('heading_title');
		$this->data['text_careers'] = $this->language->get('text_careers');
		$this->data['text_attachcv'] = $this->language->get('text_attachcv');
		$this->data['text_click'] = $this->language->get('text_click');
		$this->data['text_thanks'] = $this->language->get('text_thanks');
		$this->data['text_captcha'] = $this->language->get('text_captcha');
		$this->data['entry_name'] = $this->language->get('entry_name');
		$this->data['entry_email'] = $this->language->get('entry_email');
		$this->data['entry_download'] = $this->language->get('entry_download');
		$this->data['entry_captcha'] = $this->language->get('entry_captcha');
		
		$this->data['button_continue'] = $this->language->get('button_continue');
		$this->data['continue'] = $this->url->link('common/home');

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->error['download_description'])) {
			$this->data['error_name'] = $this->error['download_description'];
		} else {
			$this->data['error_name'] = '';
		}
		
		if (isset($this->error['email'])) {
			$this->data['error_email'] = $this->error['email'];
		} else {
			$this->data['error_email'] = '';
		}

 		if (isset($this->error['download'])) {
			$this->data['error_download'] = $this->error['download'];
		} else {
			$this->data['error_download'] = '';
		}
		
 		//Extra errors
		if (isset($this->error['download'])) {
			$this->data['error_filename'] = $this->error['download'];
		} else {
			$this->data['error_filename'] = '';
		}
		if (isset($this->error['download'])) {
			$this->data['error_filetype'] = $this->error['download'];
		} else {
			$this->data['error_filetype'] = '';
		}
		if (isset($this->error['download'])) {
			$this->data['error_filesize'] = $this->error['download'];
		} else {
			$this->data['error_filesize'] = '';
		}
		//end of extra errors

		if (isset($this->error['captcha'])) {
			$this->data['error_captcha'] = $this->error['captcha'];
		} else {
			$this->data['error_captcha'] = '';
		}	
		

		$this->data['action'] = $this->url->link('information/careers');

		if (isset($this->request->post['download_description'])) {
			$this->data['download_description'] = $this->request->post['download_description'];
		} else {
			$this->data['download_description'] = '';
		}
		if (isset($this->request->post['email'])) {
			$this->data['email'] = $this->request->post['email'];
		} else {
			$this->data['email'] = '';
		}
	
		if (isset($this->request->post['captcha'])) {
			$this->data['captcha'] = $this->request->post['captcha'];
		} else {
			$this->data['captcha'] = '';
		}	    	

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/information/careers.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/information/careers.tpl';
		} else {
			$this->template = 'default/template/information/careers.tpl';
		}
		$this->children = array(
			'common/column_left',
			'common/column_right',
			'common/content_top',
			'common/content_bottom',
			'common/footer',
			'common/header'
		);
		$this->response->setOutput($this->render());		
	}
	
	public function captcha() {
		$this->load->library('captcha');
		
		$captcha = new Captcha();
		
		$this->session->data['captcha'] = $captcha->getCode();
		
		$captcha->showImage();
	}
	
	private function validate() {
		if ((strlen(utf8_decode($this->request->post['download_description'])) < 3) || (strlen(utf8_decode($this->request->post['download_description'])) > 32)) {
			$this->error['download_description'] = $this->language->get('error_name');
		}

		if (!preg_match('/^[^\@]+@.*\.[a-z]{2,6}$/i', $this->request->post['email'])) {
			$this->error['email'] = $this->language->get('error_email');
		}
		
		if ($this->request->files['download']['name']) {
			if ((utf8_strlen($this->request->files['download']['name']) < 3) || (utf8_strlen($this->request->files['download']['name']) > 128)) {
        		$this->error['download'] = $this->language->get('error_filename');
	  		}	  	
			
			//Limit file extensions
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'php'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'torrent'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'mp4'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'flv'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == '3gp'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'xls'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'dat'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'dll'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'rar'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'vob'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'pps'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'bin'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'm4a'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'tmp'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'xpi'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'bup'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'wmv'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'thm'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'dmg'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'jpg'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'JPG'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'jpeg'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'gif'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'png'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			
			if (utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) == 'txt'){
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
			

/* 			if ((utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) != "pdf")||(utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) != "doc")||(utf8_substr(strrchr($this->request->files['download']['name'], '.'), 1) != "docx")) {
       	   		$this->error['download'] = $this->language->get('error_filetype');
       		}	
 */
			if ($this->request->files['download']['size'] > 150000){
        		$this->error['download'] = $this->language->get('error_filesize');
	  		}	  	
									
			if ($this->request->files['download']['error'] != UPLOAD_ERR_OK) {
				$this->error['warning'] = $this->language->get('error_upload_' . $this->request->files['download']['error']);
			}
		}
				
		if (!isset($this->session->data['captcha']) || ($this->session->data['captcha'] != $this->request->post['captcha'])) {
			$this->error['captcha'] = $this->language->get('error_captcha');
		}
    	
		if (!$this->error) {
			return TRUE;		
		} else {
			return FALSE;
		}
	}
}
?>